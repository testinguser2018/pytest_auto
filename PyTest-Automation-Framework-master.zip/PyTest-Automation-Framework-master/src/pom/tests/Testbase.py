import pytest


@pytest.mark.usefixtures("get_driver")
class BaseTest:
    pass
